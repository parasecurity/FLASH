import argparse
import os
import datetime
from typing import Dict, List, Tuple, Optional, Union, Callable
import numpy as np
import json

import flwr as fl
from flwr.common import Metrics, Parameters, FitRes, EvaluateRes, NDArrays
from flwr.server.client_proxy import ClientProxy
from flwr.server.strategy import FedAvg


# Create a custom strategy based on FedAvg that coordinates class information
class ConsistentClassesStrategy(FedAvg):
    """Custom strategy that ensures class consistency across clients"""

    def __init__(
            self,
            min_clients: int,
            model_type: str,
            num_rounds: int,
            dataset_name: str,
            random_state: int = 42,
            **kwargs
    ):
        super().__init__(**kwargs)
        self.min_clients = min_clients
        self.model_type = model_type
        self.dataset_name = dataset_name
        self.current_round = 0
        self.num_rounds = num_rounds
        self.random_state = random_state
        self.initial_parameters = None
        # New field to track global classes across all clients
        self.global_classes = None
        # Track the timestamp for file naming
        self.timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        print(f"Starting server with {self.model_type} model")
        print(f"Requiring minimum {self.min_clients} clients")

    def initialize_parameters(self, client_manager) -> Optional[Parameters]:
        """Initialize parameters by aggregating from all available clients."""
        print("Requesting initial parameters from all available clients")

        # Get clients and their respective parameters
        clients = client_manager.sample(
            num_clients=client_manager.num_available(), min_num_clients=3
        )

        if not clients:
            return None

        # Request parameters from all clients
        config = {"model_type": self.model_type, "random_state": str(self.random_state)}
        client_params_results = []


        # Extract parameters and weights
        parameters_list = [params for params, _ in client_params_results]
        weights = [num_examples for _, num_examples in client_params_results]

        # Aggregate parameters weighted by sample counts
        parameters_aggregated = self.aggregate_parameters(parameters_list, weights)

        # Save the initial parameters
        self.initial_parameters = parameters_aggregated

        return parameters_aggregated

    # Replace the ConsistentClassesStrategy.aggregate_parameters method with this:

    def aggregate_parameters(self, parameters_list: List[Parameters], weights: List[float]) -> Parameters:
        """Simple unweighted aggregation like your implementation"""
        if not parameters_list:
            return None

        # Convert parameters to ndarrays
        parameters_ndarrays = [fl.common.parameters_to_ndarrays(p) for p in parameters_list]

        # Get the number of parameters
        num_params = len(parameters_ndarrays[0])

        # Initialize aggregated parameters
        aggregated_ndarrays = [np.zeros_like(parameters_ndarrays[0][i]) for i in range(num_params)]

        # Simple average aggregation (unweighted)
        for param_idx in range(num_params):
            for client_idx in range(len(parameters_ndarrays)):
                aggregated_ndarrays[param_idx] += parameters_ndarrays[client_idx][param_idx]

            # Divide by number of clients
            aggregated_ndarrays[param_idx] = aggregated_ndarrays[param_idx] / len(parameters_ndarrays)

        # Convert back to Flower Parameters
        return fl.common.ndarrays_to_parameters(aggregated_ndarrays)

    def configure_fit(self, server_round: int, parameters, client_manager):
        """Configure clients for training without class management"""
        self.current_round = server_round

        # Get standard client/config pairs from parent class
        client_config_pairs = super().configure_fit(server_round, parameters, client_manager)

        # Add custom configuration to each client config
        for _, fit_ins in client_config_pairs:
            # Add round information and model type
            fit_ins.config["round"] = str(server_round)
            fit_ins.config["total_rounds"] = str(self.num_rounds)
            fit_ins.config["model_type"] = self.model_type
            fit_ins.config["random_state"] = str(self.random_state)

            # Skip adding global classes information
        return client_config_pairs
    def configure_evaluate(self, server_round: int, parameters, client_manager):
        """Configure clients for evaluation with final round flag and global classes"""
        # Get standard client/config pairs from parent class
        client_config_pairs = super().configure_evaluate(server_round, parameters, client_manager)

        # Add custom configuration to each client config
        for _, eval_ins in client_config_pairs:
            # Flag if this is the final round
            eval_ins.config["round"] = str(server_round)
            eval_ins.config["model_type"] = self.model_type
            eval_ins.config["random_state"] = str(self.random_state)

            # Add global classes information as JSON string
            if self.global_classes is not None:
                eval_ins.config["global_classes"] = json.dumps(self.global_classes.tolist())

            if server_round == self.num_rounds:
                eval_ins.config["save_model"] = "true"

        return client_config_pairs

    def aggregate_fit(self, server_round: int, results, failures):
        """Aggregate fit results using weighted averaging"""
        # Call parent class to aggregate results
        aggregated = super().aggregate_fit(server_round, results, failures)

        if aggregated is not None:
            # Log metrics for this round
            print(f"Round {server_round} training completed:")
        return aggregated

    def aggregate_evaluate(self, server_round: int, results, failures) -> Optional[Tuple[float, Dict[str, float]]]:
        """Aggregate evaluation results using unweighted average"""
        if not results:
            return None

        # Extract f1 scores from client results - unweighted approach
        f1_scores = [res.metrics.get("f1_score", 0.0) for _, res in results]

        # Calculate unweighted average
        if f1_scores:
            avg_f1 = sum(f1_scores) / len(f1_scores)
            # Convert to loss
            loss = 1.0 - avg_f1
        else:
            # Default if no scores available
            avg_f1 = 0.0
            loss = 1.0

        # Create metrics dictionary
        metrics = {"f1_score": avg_f1}

        # Log detailed metrics for this round
        print(f"Round {server_round} evaluation completed:")
        print(f"  Unweighted Test F1 score: {avg_f1:.4f}")

        # Log client-specific results
        print(f"  Client results:")
        for client, res in results:
            print(f"    Client {client.cid}: "
                  f"Test F1 score = {res.metrics.get('f1_score', 'N/A')}, "
                  f"Samples = {res.num_examples}")

        # Print final results banner
        if server_round == self.num_rounds:
            print("\nAll rounds completed! Final results:")
            print(f"  Final loss: {loss:.4f}")
            print(f"  Final Unweighted Test F1 score: {avg_f1:.4f}")

            # Create results directory if it doesn't exist
            os.makedirs("./results", exist_ok=True)

            # Generate result filename with dataset, model, and timestamp
            result_filename = f"./results/test_f1_{self.dataset_name}_{self.model_type}_{self.timestamp}.txt"

            # Save final test F1 score to file for easier reference
            try:
                with open(result_filename, "w") as f:
                    f.write(f"Dataset: {self.dataset_name}\n")
                    f.write(f"Model: {self.model_type}\n")
                    f.write(f"Timestamp: {self.timestamp}\n")
                    f.write(f"Rounds: {self.num_rounds}\n")
                    f.write(f"Final Unweighted Test F1 Score: {avg_f1:.4f}\n")

                # Also log to a single summary file that keeps track of all runs
                summary_file = "./results/all_experiments_summary.csv"
                file_exists = os.path.exists(summary_file)

                with open(summary_file, "a") as f:
                    if not file_exists:
                        f.write("timestamp,dataset,model,rounds,test_f1,aggregation\n")
                    f.write(
                        f"{self.timestamp},{self.dataset_name},{self.model_type},{self.num_rounds},{avg_f1:.4f},unweighted\n")

                print(f"  Final Unweighted Test F1 score saved to {result_filename}")

                # Print the final result with clear marking as the last line for easy extraction
                print("=" * 50)
                print(
                    f"FINAL_RESULT: dataset={self.dataset_name}, model={self.model_type}, test_f1={avg_f1:.4f}, aggregation=unweighted")
                print("=" * 50)
            except Exception as e:
                print(f"  Error saving test F1 score: {e}")

        return loss, metrics


def main():
    # Parse arguments
    parser = argparse.ArgumentParser(description="Flower server")
    parser.add_argument("--rounds", type=int, default=3, help="Number of rounds")
    parser.add_argument("--min-clients", type=int, default=3, help="Minimum number of clients")
    parser.add_argument("--model", type=str,
                        choices=["GNB", "SGDC", "LogReg", "MLPC"],
                        help="Model type")
    parser.add_argument("--dataset", type=str, required=True, help="Dataset name")
    parser.add_argument("--port", type=int, default=8080, help="Server port")
    parser.add_argument("--random-state", type=int, default=42, help="Random state for reproducibility")
    args = parser.parse_args()

    # Create output directory for models and results
    os.makedirs("./models", exist_ok=True)
    os.makedirs("./results", exist_ok=True)

    # # Configure strategy
    strategy = ConsistentClassesStrategy(
        min_clients=args.min_clients,
        model_type=args.model,
        num_rounds=args.rounds,
        dataset_name=args.dataset,
        random_state=args.random_state,
        min_fit_clients=args.min_clients,
        min_available_clients=args.min_clients,
        min_evaluate_clients=args.min_clients,
        fraction_fit=1.0,
        fraction_evaluate=1.0,
    )

    # Configure server
    server_config = fl.server.ServerConfig(num_rounds=args.rounds)

    # Print experiment start information
    print("=" * 50)
    print(f"Starting federated learning experiment:")
    print(f"  Dataset: {args.dataset}")
    print(f"  Model: {args.model}")
    print(f"  Rounds: {args.rounds}")
    print(f"  Minimum clients: {args.min_clients}")
    print("=" * 50)

    # Start the server using the current Flower API
    fl.server.start_server(
        server_address=f"0.0.0.0:{args.port}",
        config=server_config,
        strategy=strategy
    )


if __name__ == "__main__":
    main()