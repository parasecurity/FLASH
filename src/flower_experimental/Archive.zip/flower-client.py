import argparse
import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import SGDClassifier, LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import f1_score
import flwr as fl
from typing import Dict, List, Optional, Tuple, Union
# from flwr.common import NDArrays, FitIns, EvaluateIns, FitRes, EvaluateRes, Parameters, Config

# Path to dataset files
DATA_PATH = './datasets/'
np.random.seed(42)

# Define a NumPyClient
class FlowerClient(fl.client.NumPyClient):
    def __init__(self, client_id, dataset_name, model_type, random_state=42):
        self.client_id = client_id
        self.dataset_name = dataset_name
        self.model_type = model_type
        self.random_state = random_state
        self.scaler = StandardScaler()

        # Flag to track if model has been properly initialized
        self.model_initialized = False

        # Track classes seen during training for consistent partial_fit
        self.classes = None

        print(f"Client {client_id} initialized with model type: {model_type} and random_state: {random_state}")

        # Load client data
        self.load_data()

        # Create model
        self.create_model()

        self.simpleFit()

        # Ensure classes consistency by determining max number of classes across all clients
        # We'll set this after the first server aggregation

        print(f"Client {client_id} prepared with {len(self.y_train)} training samples")

    def load_data(self):
        """Load client data from CSV files"""
        # Construct file paths
        train_path = f"{DATA_PATH}{self.dataset_name}_federated/{self.dataset_name}_client_{self.client_id}_train.csv"
        test_path = f"{DATA_PATH}{self.dataset_name}_federated/{self.dataset_name}_client_{self.client_id}_test.csv"

        # Load data with a fixed index to ensure consistent ordering
        train_df = pd.read_csv(train_path, header=0)
        test_df = pd.read_csv(test_path, header=0)

        # Sort by index before dropping NA to ensure consistent row ordering
        train_df = train_df.sort_index().dropna()
        test_df = test_df.sort_index().dropna()

        # Prepare target encoder and transform
        self.target_encoder = LabelEncoder()
        # Sort unique values before fitting to ensure consistent encoding
        unique_targets = sorted(train_df['target'].unique())
        self.target_encoder.fit(unique_targets)
        self.y_train = self.target_encoder.transform(train_df['target'])

        # Transform test data, mapping unknown values to a new class
        self.y_test = np.array([
            self.target_encoder.transform([val])[0] if val in self.target_encoder.classes_
            else -1 for val in test_df['target']
        ])

        # Get categorical columns in a deterministic order
        categorical_columns = sorted(train_df.select_dtypes(include=['object', 'category']).columns)
        categorical_columns = [col for col in categorical_columns if col != 'target']

        # Initialize feature encoders dictionary
        self.feature_encoders = {}

        # Process each categorical feature
        X_train = train_df.drop('target', axis=1)
        X_test = test_df.drop('target', axis=1)

        for col in categorical_columns:
            encoder = LabelEncoder()
            # Fit on training data only
            encoder.fit(X_train[col])
            n_classes_feat = len(encoder.classes_)
            self.feature_encoders[col] = encoder

            # Transform training data
            X_train[col] = encoder.transform(X_train[col])
            # Transform test data, mapping unknown values to a new class
            X_test[col] = np.array([
                encoder.transform([val])[0] if val in encoder.classes_
                else n_classes_feat for val in X_test[col]
            ])
        # Save to class variable
        self.X_train = X_train
        self.X_test = X_test

        # print(f"Client {self.client_id} data loaded: {self.n_features} features, {self.n_classes} classes")

    def create_model(self, model_type=None, random_state=42):
        """Create model based on specified type"""
        model_type = model_type or self.model_type
        self.model_type = model_type
        self.random_state = random_state

        print(f"Creating model of type: {model_type} with random_state: {random_state}")

        if model_type == "GNB":
            self.model = GaussianNB()
        elif model_type == "SGDC":
            self.model = SGDClassifier(
                loss='log_loss',
                penalty='l2',
                alpha=0.01,
                max_iter=1000,
                tol=1e-3,
                learning_rate='adaptive',
                eta0=0.005,
                power_t=0.25,
                warm_start=True,
                average=False,
                random_state=random_state
            )
        elif model_type == "MLPC":
            # For MLPC, we need to make warm_start=False to avoid class mismatch issues
            self.model = MLPClassifier(
                warm_start=True,
                random_state=random_state,
            )
        else:
            raise ValueError(f"Unsupported model type: {model_type}")

    def initialize_model(self, server_classes=None):
        """Initialize model by fitting it with data to create necessary attributes"""
        print(f"Initializing model for client {self.client_id}")

        # Scale features
        X_train_scaled = self.scaler.fit_transform(self.X_train)

        # Determine classes to use
        classes_to_use = server_classes if server_classes is not None else np.unique(self.y_train)
        self.classes = classes_to_use

        try:
            # Other models can use partial_fit if available
            if hasattr(self.model, 'partial_fit') and callable(self.model.partial_fit):
                self.model.partial_fit(X_train_scaled, self.y_train, classes=classes_to_use)
            else:
                self.model.fit(X_train_scaled, self.y_train)

            # Ensure classes_ attribute is set
            if not hasattr(self.model, 'classes_'):
                self.model.classes_ = classes_to_use

            print(f"Model initialized and fit with {len(self.y_train)} samples")
            self.model_initialized = True
        except Exception as e:
            print(f"Error initializing model: {e}")
            print("Will try to continue with default initialization")

    def set_parameters(self, parameters: List[np.ndarray]) -> None:
        """Update model with parameters from server - simplified"""
        if not parameters or len(parameters) == 0:
            return

        try:
            # Set parameters based on model type
            if self.model_type == "GNB":
                self.model.var_ = parameters[0]
                self.model.theta_ = parameters[1]

            elif self.model_type == "SGDC":
                self.model.coef_ = parameters[0]
                self.model.intercept_ = parameters[1]

            # elif self.model_type == "MLPC":
            #     n_layers = len(parameters) // 2
            #     self.model.coefs_ = parameters[:n_layers]
            #     self.model.intercepts_ = parameters[n_layers:]

        except Exception as e:
            print(f"Error setting parameters: {e}")

    def simpleFit(self):
        # Model-specific random state settings
        if hasattr(self.model, 'random_state'):
            self.model.random_state = 42

        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(self.X_train)
        X_test_scaled = self.scaler.transform(self.X_test)

        # Include the extra class for unknowns in the classes parameter
        n_classes = len(self.target_encoder.classes_)
        all_classes = np.arange(n_classes + 1)  # +1 for unknown class

        if hasattr(self.model, 'partial_fit') and callable(self.model.partial_fit):
            self.model.partial_fit(X_train_scaled, self.y_train, classes=all_classes)
        else:
            self.model.fit(X_train_scaled, self.y_train)

        res = {
            'test': f1_score(self.y_test, self.model.predict(X_test_scaled), average='weighted'),
            'train': f1_score(self.y_train, self.model.predict(X_train_scaled), average='weighted')
        }
        return res
    def fit(self, parameters: List[np.ndarray], config: Dict[str, str]) -> Tuple[
        List[np.ndarray], int, Dict[str, float]]:
        """Train model on local data - simplified to match your implementation"""
        self.set_parameters(parameters)

        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(self.X_train)

        if hasattr(self.model, 'partial_fit') and callable(self.model.partial_fit):
            # Simply call partial_fit without special class handling
            self.model.partial_fit(X_train_scaled, self.y_train)
        else:
            self.model.fit(X_train_scaled, self.y_train)

        # Evaluate model
        X_test_scaled = self.scaler.transform(self.X_test)
        test_pred = self.model.predict(X_test_scaled)
        test_f1 = f1_score(self.y_test, test_pred, average='weighted')

        # Return updated parameters with metrics
        return self.get_parameters({}), len(self.y_train), {"f1_score": float(test_f1)}

    def get_parameters(self, config: Dict[str, str]) -> List[np.ndarray]:
        """Get model parameters to send to server - simplified version"""
        if self.model_type == "GNB":
            return [
                self.model.var_.copy(),
                self.model.theta_.copy(),
                # self.model.class_prior_.copy() if hasattr(self.model, 'class_prior_') else np.array([])
            ]
        elif self.model_type == "SGDC":
            return [
                self.model.coef_.copy(),
                self.model.intercept_.copy()
            ]
        elif self.model_type == "MLPC":
            weights = []
            # Add all layer weights first
            for layer_weights in self.model.coefs_:
                weights.append(layer_weights.copy())
            # Then add all biases
            for layer_bias in self.model.intercepts_:
                weights.append(layer_bias.copy())
            return weights
        else:
            print(f"Unsupported model type for parameters: {self.model_type}")
            return []

    def create_model(self, model_type=None, random_state=None):
        """Create model based on specified type - with MLPC support"""
        model_type = model_type or self.model_type
        random_state = random_state or self.random_state
        self.model_type = model_type
        self.random_state = random_state

        print(f"Creating model of type: {model_type} with random_state: {random_state}")

        if model_type == "GNB":
            self.model = GaussianNB()
        elif model_type == "SGDC":
            self.model = SGDClassifier(
                loss='log_loss',
                penalty='l2',
                alpha=0.01,
                max_iter=1000,
                tol=1e-3,
                learning_rate='adaptive',
                eta0=0.005,
                power_t=0.25,
                warm_start=True,
                average=False,
                random_state=random_state
            )
        elif model_type == "MLPC":
            # Improved MLPC implementation with parameters similar to your implementation
            self.model = MLPClassifier(
                random_state=random_state,
                warm_start=True
            )
        else:
            raise ValueError(f"Unsupported model type: {model_type}")

    def evaluate(self, parameters: List[np.ndarray], config: Dict[str, str]) -> Tuple[float, int, Dict[str, float]]:
        """Evaluate model on test data - simplified version"""
        try:
            # Update model with server parameters
            self.set_parameters(parameters)

            # If model isn't initialized, try to initialize it
            if not self.model_initialized:
                print("Model not initialized for evaluation, initializing now...")
                self.initialize_model()

            # Scale features - consistent with your implementation
            X_test_scaled = self.scaler.transform(self.X_test)

            # Evaluate model on test data
            y_pred = self.model.predict(X_test_scaled)
            loss = 1.0 - self.model.score(X_test_scaled, self.y_test)
            test_f1 = f1_score(self.y_test, y_pred, average='weighted')

            print(f"Evaluation completed with Test F1 score: {test_f1:.4f}")

            # Return test F1 as the primary metric
            return loss, len(self.y_test), {"f1_score": float(test_f1)}

        except Exception as e:
            print(f"Error during evaluation: {e}")
            import traceback
            traceback.print_exc()

            # Return default metrics as fallback
            return 1.0, len(self.y_test), {"f1_score": 0.0, "error": str(e)}


def main():
    # Parse arguments
    parser = argparse.ArgumentParser(description="Flower client")
    parser.add_argument("--client-id", "--client_id", dest="client_id", type=int, required=True, help="Client ID")
    parser.add_argument("--dataset", type=str, required=True, help="Dataset name")
    parser.add_argument("--server", type=str, default="127.0.0.1:8080", help="Server address")
    parser.add_argument("--model", type=str, default="GNB",
                        choices=["GNB", "SGDC", "LogReg", "MLPC"],
                        help="Model type (default: GNB)")
    parser.add_argument("--random-state", "--random_state", dest="random_state", type=int, default=42,
                        help="Random state for reproducibility")

    # Print that arguments are being parsed and show command line args
    import sys
    print(f"Parsing arguments: {sys.argv}")

    # Try to parse known args first to debug
    args, unknown = parser.parse_known_args()
    if unknown:
        print(f"Warning: Unknown arguments: {unknown}")

    # Parse args fully
    args = parser.parse_args()

    # Check if dataset files exist
    dataset_dir = f"{DATA_PATH}{args.dataset}_federated"
    client_train_file = f"{dataset_dir}/{args.dataset}_client_{args.client_id}_train.csv"
    client_test_file = f"{dataset_dir}/{args.dataset}_client_{args.client_id}_test.csv"

    if not os.path.exists(client_train_file) or not os.path.exists(client_test_file):
        raise FileNotFoundError(f"Client data files not found for client {args.client_id}")

    # Create Flower client
    client = FlowerClient(
        client_id=args.client_id,
        dataset_name=args.dataset,
        model_type=args.model,
        random_state=args.random_state
    )

    # Print a message about starting the client
    print(f"Starting client connection to {args.server}")

    # Start the client using the latest Flower API
    fl.client.start_numpy_client(server_address=args.server, client=client)


if __name__ == "__main__":
    main()